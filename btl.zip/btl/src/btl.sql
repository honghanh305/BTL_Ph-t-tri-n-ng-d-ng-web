-- =========================================================================
-- FILE: tthu_database_setup.sql
-- CƠ SỞ DỮ LIỆU HOÀN CHỈNH CHO SMART STUDY PLATFORM (Tên DB: tthu)
-- =========================================================================

-- 1. THIẾT LẬP DATABASE VÀ TẠO BẢNG (SCHEMA)
-- Cập nhật tên database từ 'vidu' thành 'tthu'
-- Cần đảm bảo thông tin này khớp với DBConnection.java của bạn!

CREATE DATABASE IF NOT EXISTS tthu CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tthu;

-- 1.1 Bảng NguoiDung (Users)
-- Chức năng: Đăng ký/Đăng nhập (DangKyServlet/DangNhapServlet)
CREATE TABLE NguoiDung (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hoten VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    matkhau VARCHAR(255) NOT NULL, 
    vaitro ENUM('Student', 'Creator', 'Admin') NOT NULL DEFAULT 'Student',
    anhdaidien VARCHAR(512) NULL,
    trangthai ENUM('Active', 'Suspended') NOT NULL DEFAULT 'Active',
    ngaytao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- 1.2 Bảng MucTapHoc (Courses / Topics)
-- Chức năng: Phân loại tài liệu, hiển thị danh sách khóa học
CREATE TABLE MucTapHoc (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tenmuctaphoc VARCHAR(255) NOT NULL,
    mota TEXT NOT NULL,
    hinhanh VARCHAR(512) NULL,
    nguoidungid INT,
    ngaytao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    congkhai BOOLEAN NOT NULL DEFAULT TRUE,
    FOREIGN KEY (nguoidungid) REFERENCES NguoiDung(id) ON DELETE SET NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- 1.3 Bảng TaiLieu (Documents / Files)
-- Chức năng: Quản lý tệp tin tải lên (TaiLenServlet)
CREATE TABLE TaiLieu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    muctaphocid INT NOT NULL,
    tieude VARCHAR(255) NOT NULL,
    mota_ngan VARCHAR(500) NULL,
    duongdanfile VARCHAR(512) NOT NULL, 
    tenfilegoc VARCHAR(255) NOT NULL,
    dinhdang VARCHAR(10) NOT NULL,
    nguoidungid INT,
    luottaive INT NOT NULL DEFAULT 0,
    luotxem INT NOT NULL DEFAULT 0,
    ngaytailen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (muctaphocid) REFERENCES MucTapHoc(id) ON DELETE CASCADE,
    FOREIGN KEY (nguoidungid) REFERENCES NguoiDung(id) ON DELETE SET NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

-- 1.4 Bảng ThongKeTruyCap (Access Statistics)
-- Chức năng: Ghi lại hành động (dành cho DataServlet mở rộng)
CREATE TABLE ThongKeTruyCap (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nguoidungid INT NULL,
    tailieuid INT NULL,
    hanhdong ENUM('View', 'Download', 'Login', 'Register') NOT NULL,
    thoigian TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45) NULL,
    FOREIGN KEY (nguoidungid) REFERENCES NguoiDung(id) ON DELETE SET NULL,
    FOREIGN KEY (tailieuid) REFERENCES TaiLieu(id) ON DELETE SET NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

CREATE TABLE Feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nguoidungid INT NOT NULL,
    noi_dung TEXT NOT NULL,
    xep_hang INT CHECK (xep_hang >= 1 AND xep_hang <= 5),
    ngay_tao DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    -- Khóa ngoại liên kết với bảng NguoiDung
    FOREIGN KEY (nguoidungid) REFERENCES NguoiDung(id)
    -- Thêm ON DELETE CASCADE nếu bạn muốn xóa feedback khi người dùng bị xóa (tùy chọn)
    
    
);


CREATE TABLE CamNhan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hoten VARCHAR(255) NOT NULL,
    vaitro VARCHAR(100) NOT NULL, -- Ví dụ: "Sinh viên", "Lập trình viên"
    noiDung TEXT NOT NULL,
    xepHang INT CHECK (xepHang BETWEEN 1 AND 5), -- Xếp hạng từ 1 đến 5 sao
    thoiGian TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Thêm dữ liệu mẫu để kiểm tra tính năng "Xem thêm"
INSERT INTO CamNhan (hoten, vaitro, noiDung, xepHang) VALUES 
('Phạm Văn K', 'Sinh viên IT', 'Thật tuyệt vời, nền tảng này có tài liệu rất phong phú!', 5),
('Đặng Thị L', 'Kỹ sư phần mềm', 'Giao diện đẹp và dễ sử dụng, tôi rất thích mục khám phá.', 4),
('Trần Văn M', 'Designer', 'Các bài giảng về UI/UX rất chi tiết và dễ hiểu.', 5),
('Lê Thị N', 'Giáo viên', 'Tôi đã chia sẻ tài liệu của mình và được cộng đồng đón nhận.', 5),
('Vũ Đình O', 'Content Creator', 'Có một số lỗi nhỏ về tốc độ tải, nhưng nội dung chất lượng.', 4),
('Bùi Văn P', 'Quản lý dự án', 'Tuyệt vời, sẽ giới thiệu cho đồng nghiệp.', 5),
('Nguyễn Thị Q', 'Thực tập sinh', 'Nhờ nền tảng này, tôi đã tìm được tài liệu ôn thi hiệu quả.', 4);



-- Tùy chọn: Thêm một vài dữ liệu mẫu để kiểm tra
INSERT INTO Feedback (nguoidungid, noi_dung, xep_hang) VALUES 
(1, 'Giao diện thân thiện, tài liệu đa dạng và hữu ích. Cảm ơn đội ngũ phát triển!', 5),
(2, 'Trang web rất dễ sử dụng, tôi có thể tìm thấy tài liệu mình cần chỉ trong vài giây.', 4),
(1, 'Chức năng tải lên hoạt động ổn định, tôi thích cách quản lý file ở đây.', 5),
(3, 'Tôi nghĩ nên thêm chức năng bình luận vào từng tài liệu.', 3);
-- =====================================
-- 2. CHÈN DỮ LIỆU MẪU (TEST DATA)
-- =====================================

-- 2.1 Dữ liệu Mẫu cho Bảng NguoiDung (3 tài khoản test)
-- Mật khẩu cho mọi tài khoản là: 123456
INSERT INTO NguoiDung (id, hoten, email, matkhau, vaitro) VALUES
(1, 'Admin Hệ Thống', 'admin.sys@gmail.com', '123456', 'Admin'),
(2, 'Nguyễn Văn Tạo (Creator)', 'nguyenvantao@gmail.com', '123456', 'Creator'),
(3, 'Lê Thị Học Viên (Student)', 'lethihocvien@gmail.com', '123456', 'Student')
ON DUPLICATE KEY UPDATE hoten=VALUES(hoten);

-- 2.2 Dữ liệu Mẫu cho Bảng MucTapHoc (5 Khóa học)
INSERT INTO MucTapHoc (id, tenmuctaphoc, mota, nguoidungid) VALUES
(101, 'Lập Trình Web với Java Servlet & JSP', 'Khóa học chuyên sâu về phát triển ứng dụng web động sử dụng Java Servlet và JSP.', 2),
(102, 'Cơ Sở Dữ Liệu MySQL Nâng Cao', 'Nghiên cứu về tối ưu hóa truy vấn, thiết kế Schema và bảo mật dữ liệu.', 1),
(103, 'Thiết Kế Giao Diện Web (HTML/CSS)', 'Học cách xây dựng các bố cục đẹp và tương thích trên mọi thiết bị.', 2),
(104, 'Thuật Toán và Cấu Trúc Dữ Liệu', 'Khóa học cơ bản giúp tối ưu hóa hiệu suất chương trình.', 3),
(105, 'Giới Thiệu về Hệ Điều Hành Linux', 'Khám phá các lệnh cơ bản và quản lý hệ thống Linux.', 1)
ON DUPLICATE KEY UPDATE tenmuctaphoc=VALUES(tenmuctaphoc);
INSERT INTO MucTapHoc (id, tenmuctaphoc, mota, nguoidungid) VALUES
(106, 'Phân Tích Dữ Liệu với Python Pandas', 'Học cách làm sạch, biến đổi và phân tích dữ liệu lớn bằng thư viện Pandas.', 1),
(107, 'Lập Trình Di Động với React Native', 'Xây dựng ứng dụng di động đa nền tảng (iOS/Android) từ một codebase duy nhất.', 2),
(108, 'Quản Lý Dự Án theo Phương Pháp Agile Scrum', 'Nghiên cứu các nguyên tắc, vai trò và quy trình của khung làm việc Scrum.', 3),
(109, 'Học Máy Cơ Bản (Machine Learning)', 'Giới thiệu về các thuật toán học giám sát và không giám sát, cùng ứng dụng thực tế.', 1),
(110, 'Đồ Họa Máy Tính với OpenGL', 'Tìm hiểu cách hiển thị đồ họa 2D và 3D, từ các khái niệm cơ bản đến nâng cao.', 2),
(111, 'Mạng Máy Tính và Giao Thức TCP/IP', 'Khám phá kiến thức nền tảng về hoạt động của mạng, định tuyến và các giao thức chính.', 3),
(112, 'Thiết Kế Trải Nghiệm Người Dùng (UX/UI)', 'Tập trung vào quy trình thiết kế lấy người dùng làm trung tâm và tạo ra giao diện hiệu quả.', 1),
(113, 'Khoa Học Dữ Liệu và Trực Quan Hóa', 'Sử dụng các công cụ như Matplotlib và Seaborn để kể chuyện qua dữ liệu.', 2),
(114, 'Kiểm Thử Phần Mềm và Tự Động Hóa', 'Tìm hiểu các loại kiểm thử, lập kế hoạch kiểm thử và sử dụng công cụ tự động hóa.', 3),
(115, 'Bảo Mật Ứng Dụng Web (OWASP Top 10)', 'Nghiên cứu các lỗ hổng bảo mật phổ biến và cách phòng chống chúng trong ứng dụng web.', 1),
(116, 'Lập Trình Web Backend với Node.js và Express', 'Phát triển các API RESTful mạnh mẽ và có khả năng mở rộng bằng JavaScript.', 2),
(117, 'Giới Thiệu về Điện Toán Đám Mây (Cloud Computing)', 'Tổng quan về AWS, Azure và Google Cloud, bao gồm các mô hình dịch vụ IaaS, PaaS, SaaS.', 3),
(118, 'Phân Tích Thống Kê với R', 'Sử dụng ngôn ngữ R để thực hiện các phân tích thống kê chuyên sâu và mô hình hóa.', 1),
(119, 'Blockchain và Tiền Điện Tử Cơ Bản', 'Hiểu về công nghệ sổ cái phân tán, cơ chế đồng thuận và ứng dụng của nó.', 2),
(120, 'Kỹ Thuật Vi Điều Khiển (Microcontroller) và Arduino', 'Lập trình các hệ thống nhúng và tương tác với các cảm biến vật lý.', 3)
ON DUPLICATE KEY UPDATE tenmuctaphoc=VALUES(tenmuctaphoc);

-- 2.3 Dữ liệu Mẫu cho Bảng TaiLieu (6 Tài liệu)
INSERT INTO TaiLieu (id, muctaphocid, tieude, mota_ngan, duongdanfile, tenfilegoc, dinhdang, nguoidungid, luottaive, luotxem) VALUES
(201, 101, 'Bài giảng Servlet cơ bản (Slide PPT)', 'Tóm tắt các khái niệm cơ bản về Servlet Lifecycle và xử lý request/response.', 'uploads/servlet_co_ban.pdf', 'ServletCoBan.pdf', 'pdf', 2, 50, 120),
(202, 101, 'Mã nguồn Form Handling (ZIP)', 'Tệp nén chứa mã nguồn hoàn chỉnh của ví dụ xử lý dữ liệu form POST/GET.', 'uploads/code_form_handling.zip', 'CodeFormHandling.zip', 'zip', 2, 20, 80),
(203, 102, 'Kỹ thuật Tối ưu hóa Index', 'Tài liệu hướng dẫn chuyên sâu về việc tạo và quản lý Index để tối ưu hóa hiệu suất truy vấn.', 'uploads/toi_uu_index.docx', 'ToiUuIndex.docx', 'docx', 1, 35, 95),
(204, 103, 'Hướng dẫn CSS Flexbox và Grid', 'Tài liệu chi tiết về hai công cụ bố cục hiện đại nhất của CSS.', 'uploads/flex_grid_cheat_sheet.pdf', 'FlexGrid.pdf', 'pdf', 2, 80, 200),
(205, 104, 'Phân tích độ phức tạp (Big O Notation)', 'Giải thích chuyên sâu về cách đánh giá độ phức tạp thời gian và không gian của các thuật toán.', 'uploads/big_o_analysis.docx', 'BigO.docx', 'docx', 3, 40, 110),
(206, 105, 'Sổ tay Lệnh Linux Cơ Bản', 'Tập hợp các lệnh terminal thiết yếu nhất để bắt đầu làm việc với Linux.', 'uploads/linux_command_list.txt', 'LinuxCommands.txt', 'txt', 1, 60, 150)
ON DUPLICATE KEY UPDATE tieude=VALUES(tieude);
SELECT *FROM NguoiDung 
SELECT *FROM ThongKe
SELECT *FROM TruyCap
SELECT *FROM TaiLieu
SELECT *FROM MucTapHoc
SELECT *FROM Feedback
-- Thêm cột tenFile vào bảng TaiLieu
ALTER TABLE TaiLieu
ADD tenFile VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
SELECT * FROM TaiLieu ORDER BY id DESC LIMIT 1;
-- Thêm cột Level (Cấp độ)
ALTER TABLE MucTapHoc
ADD CapDo VARCHAR(50) NOT NULL DEFAULT 'Cơ bản';

-- Thêm cột Icon (Biểu tượng cho thẻ khóa học)
ALTER TABLE MucTapHoc
ADD IconClass VARCHAR(100) NOT NULL DEFAULT 'fa-book';

-- Thêm cột Background Color (Màu nền cho thẻ khóa học)
ALTER TABLE MucTapHoc
ADD BgClass VARCHAR(100) NOT NULL DEFAULT 'bg-primary';

-- Cập nhật dữ liệu mẫu (Tùy chọn)
UPDATE MucTapHoc SET CapDo = 'Cơ bản', IconClass = 'fa-code', BgClass = 'bg-primary' WHERE id = 101;
UPDATE MucTapHoc SET CapDo = 'Nâng cao', IconClass = 'fa-database', BgClass = 'bg-success' WHERE id = 102;
UPDATE MucTapHoc SET CapDo = 'Cơ bản', IconClass = 'fa-paint-brush', BgClass = 'bg-info' WHERE id = 103;
UPDATE MucTapHoc SET CapDo = 'Chuyên sâu', IconClass = 'fa-flask', BgClass = 'bg-warning' WHERE id = 104;
UPDATE MucTapHoc SET CapDo = 'Cơ bản', IconClass = 'fa-terminal', BgClass = 'bg-danger' WHERE id = 105;

UPDATE TaiLieu
SET tenFile = tieude
WHERE tenFile IS NULL;
-- 1. Thêm cột loai_noi_dung vào bảng TaiLieu để lưu loại file (Video/Document)
ALTER TABLE TaiLieu
ADD loai_noi_dung VARCHAR(50) NOT NULL DEFAULT 'Document' AFTER tieude;

-- (Tùy chọn) Thêm cột tenFile nếu bạn chưa chạy nó trong script setup
ALTER TABLE TaiLieu
ADD tenFile VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE TaiLieu
ADD trangThai ENUM('Chờ duyệt', 'Đã duyệt', 'Bị từ chối') NOT NULL DEFAULT 'Chờ duyệt';
