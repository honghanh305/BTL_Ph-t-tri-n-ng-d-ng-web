package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
    // THÔNG TIN KẾT NỐI (Dựa trên thông tin bạn cung cấp)
    private static final String URL = "jdbc:mysql://localhost:3306/tthu?useUnicode=true&characterEncoding=UTF-8"; 
    private static final String USER = "root";
    private static final String PASSWORD = "12345678"; 
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver"; // MySQL 8+

    public static Connection getDBConnection() throws SQLException {
        try {
            // 1. Nạp Driver (Kiểm tra lỗi thiếu file .jar)
            Class.forName(DRIVER); 
        } catch (ClassNotFoundException e) {
            // In ra log server để dễ dàng debug lỗi thiếu file .jar
            System.err.println("LỖI CẤP 1: THIẾU DRIVER JDBC");
            e.printStackTrace();
            throw new SQLException("MySQL JDBC Driver không tìm thấy. Vui lòng kiểm tra file mysql-connector-java.jar trong WEB-INF/lib.", e);
        }
        
        try {
            // 2. Kết nối đến Database
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            // Lỗi kết nối (Sai username/password/URL)
            System.err.println("LỖI CẤP 2: KẾT NỐI DB THẤT BẠI");
            e.printStackTrace();
            throw new SQLException("Không thể kết nối DB. Vui lòng kiểm tra URL, User, Password (Chi tiết: " + e.getMessage() + ")", e.getSQLState());
        }
    }
}