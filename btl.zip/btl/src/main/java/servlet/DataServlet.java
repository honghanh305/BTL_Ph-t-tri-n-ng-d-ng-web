package servlet;

import dao.DBConnection; 
import java.io.*;
import java.sql.*; 
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/data")
public class DataServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;

        int totalCourses = 0;
        int totalDocuments = 0;
        int totalUsers = 0;

        try {
            conn = DBConnection.getDBConnection();

            // 1. Đếm Tổng số Tài liệu (Documents) từ bảng TaiLieu
            try (Statement stmtDoc = conn.createStatement();
                 ResultSet rsDoc = stmtDoc.executeQuery("SELECT COUNT(*) AS total FROM TaiLieu")) {
                if (rsDoc.next()) {
                    totalDocuments = rsDoc.getInt("total");
                }
            }
            
            // 2. Đếm Tổng số Người dùng (Users) từ bảng NguoiDung
            try (Statement stmtUser = conn.createStatement();
                 ResultSet rsUser = stmtUser.executeQuery("SELECT COUNT(*) AS total FROM NguoiDung")) {
                if (rsUser.next()) {
                    totalUsers = rsUser.getInt("total");
                }
            }

            // 3. Đếm Tổng số Khóa học/Chủ đề (Courses) từ bảng MucTapHoc
            try (Statement stmtCourse = conn.createStatement();
                 ResultSet rsCourse = stmtCourse.executeQuery("SELECT COUNT(*) AS total FROM MucTapHoc")) {
                if (rsCourse.next()) {
                    totalCourses = rsCourse.getInt("total");
                }
            }

            // 4. Gửi phản hồi JSON động
            String jsonResponse = String.format(
                "{\"stats\":{\"courses\":%d,\"documents\":%d,\"users\":%d},\"message\":\"Dữ liệu thống kê tải thành công!\"}",
                totalCourses, totalDocuments, totalUsers
            );
            
            resp.setStatus(HttpServletResponse.SC_OK); 
            out.print(jsonResponse);

        } catch (Exception e) {
            // Xử lý lỗi và in Stack Trace để debug
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); 
            out.print("{\"message\":\"Lỗi server nội bộ: Không thể tải dữ liệu thống kê từ DB. Chi tiết: " + e.getMessage() + "\"}");
        } finally {
            // Đóng kết nối
            if (conn != null) {
                try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }
    }
}