package servlet;

import dao.DBConnection;
import model.NguoiDung;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Scanner;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 100,      // 100MB
    maxRequestSize = 1024 * 1024 * 150    // 150MB
)
@WebServlet("/api/user/content")
public class TaiLieuActionsServlet extends HttpServlet {
    
    private static final String UPLOAD_DIR = "uploads";
    
    // ===============================================
    // HÀM TIỆN ÍCH
    // ===============================================
    
    /**
     * Hàm tiện ích để đọc nội dung của Part (dùng cho các trường form không phải file).
     */
    private String readPartToString(Part part) throws IOException {
        if (part == null) return null;
        if (part.getSize() > 0 && part.getSubmittedFileName() == null) {
            try (java.util.Scanner scanner = new java.util.Scanner(part.getInputStream(), java.nio.charset.StandardCharsets.UTF_8.name())) {
                return scanner.hasNext() ? scanner.useDelimiter("\\A").next() : null;
            }
        }
        return null;
    }

    /**
     * Hàm tiện ích: Lấy thư mục lưu trữ file và đảm bảo thư mục tồn tại.
     */
    private String getUploadPath(HttpServletRequest req) {
        ServletContext context = req.getServletContext();
        String appPath = context.getRealPath("");
        String uploadFilePath = appPath + File.separator + UPLOAD_DIR;
        File fileSaveDir = new File(uploadFilePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdirs();
        }
        return uploadFilePath;
    }

    /**
     * Hàm tiện ích để thoát các ký tự đặc biệt trong JSON.
     */
    private String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                     .replace("\"", "\\\"")
                     .replace("\n", "\\n")
                     .replace("\r", "\\r")
                     .replace("\t", "\\t");
    }

    // ====================================================================
    // 1. doGet: Lấy danh sách tài liệu (ĐÃ THÊM TRƯỜNG CẤP ĐỘ/CAP_DO)
    // ====================================================================
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        resp.setContentType("application/json;charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;
        
        HttpSession session = req.getSession(false); 
        
        // --- 1. Lấy tham số lọc từ URL (Dùng cho chế độ Public Explore) ---
        String filterPhanLoai = req.getParameter("phanloai"); 
        String filterAuthor = req.getParameter("author"); 
        String actionExplore = req.getParameter("action"); // Ví dụ: action=explore
        
        // Chế độ Khám phá công khai được kích hoạt nếu có bất kỳ tham số lọc nào hoặc action=explore
        boolean isPublicExplore = (filterPhanLoai != null || filterAuthor != null || "explore".equalsIgnoreCase(actionExplore));
        
        NguoiDung currentUser = null;
        String vaiTro = null;
        int nguoiDungId = -1;
        boolean isAdmin = false;

        // Chỉ kiểm tra session nếu session tồn tại 
        if (session != null && session.getAttribute("currentUser") != null) {
            currentUser = (NguoiDung) session.getAttribute("currentUser");
            vaiTro = currentUser.getVaitro(); 
            nguoiDungId = currentUser.getId(); 
            isAdmin = "Admin".equalsIgnoreCase(vaiTro) || "Quản trị viên".equalsIgnoreCase(vaiTro);
        }

        // Nếu người dùng không đăng nhập VÀ không phải chế độ Public Explore 
        if (!isPublicExplore && currentUser == null) {
             resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED); 
             out.print("{\"message\":\"Vui lòng đăng nhập để xem tài liệu cá nhân hoặc admin.\"}");
             return;
        }

        List<String> contentList = new ArrayList<>();
        // Key phản hồi sẽ khác nhau tùy theo chế độ
        String responseKey = isPublicExplore ? "exploreContent" : (isAdmin ? "allContent" : "userContent");

        try {
            conn = DBConnection.getDBConnection();
            PreparedStatement stmt = null;
            String selectSQL;
            List<Object> params = new ArrayList<>();
            
            // 🔥 CHẾ ĐỘ 1 (Ưu tiên): PUBLIC EXPLORE (Khám phá) - Chỉ lấy tài liệu Đã duyệt
            if (isPublicExplore) {
                
                // 🔥 THÊM cột tl.cap_do vào SELECT
                selectSQL = "SELECT tl.id, tl.tieude, tl.mota_ngan, tl.loai_noi_dung, tl.tenFile, tl.ngaytailen, tl.trangThai, tl.nguoidungid, tl.duongdanfile, nd.hoten AS tenNguoiDung, tl.cap_do " +
                            "FROM TaiLieu tl JOIN NguoiDung nd ON tl.nguoidungid = nd.id " +
                            "WHERE tl.trangThai = ? ";
                            
                params.add("Đã duyệt"); 

                // Lọc theo Loại
                if (filterPhanLoai != null && !filterPhanLoai.isEmpty() && !"all".equalsIgnoreCase(filterPhanLoai)) {
                    selectSQL += " AND tl.loai_noi_dung = ?"; 
                    params.add(filterPhanLoai);
                }

                // Lọc theo Tác giả
                if (filterAuthor != null && !filterAuthor.isEmpty()) {
                    selectSQL += " AND nd.hoten LIKE ?"; 
                    params.add("%" + filterAuthor + "%");
                }
                
                selectSQL += " ORDER BY tl.ngaytailen DESC";
                
                stmt = conn.prepareStatement(selectSQL);
                for (int i = 0; i < params.size(); i++) {
                    stmt.setObject(i + 1, params.get(i)); 
                }

            } else if (isAdmin) { // CHẾ ĐỘ 2: ADMIN (Tất cả tài liệu)
                
                // Admin lấy TẤT CẢ tài liệu, kèm TÊN NGƯỜI DÙNG (JOIN NguoiDung)
                // 🔥 THÊM cột t.cap_do vào SELECT
                selectSQL = "SELECT t.*, nd.hoten AS tenNguoiDung, nd.id AS ndId, t.cap_do FROM TaiLieu t "
                          + "JOIN NguoiDung nd ON t.nguoidungid = nd.id "
                          + "ORDER BY t.ngaytailen DESC";
                stmt = conn.prepareStatement(selectSQL);
                
            } else { // CHẾ ĐỘ 3: USER CÁ NHÂN (Tài liệu của họ)
                
                // Người dùng thường chỉ lấy tài liệu của họ
                // 🔥 THÊM cột t.cap_do vào SELECT
                selectSQL = "SELECT t.*, t.cap_do FROM TaiLieu t WHERE t.nguoidungid = ? ORDER BY t.ngaytailen DESC";
                stmt = conn.prepareStatement(selectSQL);
                stmt.setInt(1, nguoiDungId);
                
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    // Lấy Tên Người Dùng: từ cột JOIN nếu là Public/Admin, từ session nếu là User
                    String tenNguoiDung;
                    if (isPublicExplore || isAdmin) {
                        tenNguoiDung = rs.getString("tenNguoiDung");
                    } else {
                        tenNguoiDung = currentUser != null ? currentUser.getHoten() : "N/A"; 
                    }
                    
                    // Lấy loai_noi_dung
                    String phanLoai = rs.getString("loai_noi_dung");
                    
                    // Lập bản đồ các trường cần thiết
                    String jsonObject = "{"
                        + "\"id\":\"" + rs.getString("id") + "\"," 
                        + "\"tieude\":\"" + escapeJson(rs.getString("tieude")) + "\"," 
                        + "\"mota\":\"" + escapeJson(rs.getString("mota_ngan")) + "\"," // Khóa mota dùng mota_ngan
                        + "\"phanloai\":\"" + escapeJson(phanLoai) + "\","
                        // 🔥 THÊM TRƯỜNG CẤP ĐỘ MỚI
                        + "\"capDo\":\"" + escapeJson(rs.getString("cap_do")) + "\"," 
                        + "\"trangThai\":\"" + escapeJson(rs.getString("trangThai")) + "\","
                        + "\"tenFile\":\"" + escapeJson(rs.getString("tenFile")) + "\","
                        + "\"ngaytailen\":\"" + escapeJson(rs.getString("ngaytailen")) + "\","
                        + "\"nguoiDungId\":" + rs.getInt("nguoidungid") + ","
                        + "\"tenNguoiDung\":\"" + escapeJson(tenNguoiDung) + "\","
                        + "\"duongdanfile\":\"" + escapeJson(rs.getString("duongdanfile")) + "\""
                        + "}";
                    contentList.add(jsonObject);
                }

                String jsonResponse = "{\"" + responseKey + "\":[" + String.join(",", contentList) + "],\"message\":\"Tải danh sách tài liệu thành công!\"}";
                
                resp.setStatus(HttpServletResponse.SC_OK);
                out.print(jsonResponse);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\":\"Lỗi Database khi tải nội dung: " + escapeJson(e.getMessage()) + "\"}");
        } catch (Exception e) {
             e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\":\"Lỗi Server chung: " + escapeJson(e.getMessage()) + "\"}");
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }
    }
    
    // ====================================================================
    // 2. doPost: Xử lý hành động (Upload/Update/Review)
    // ====================================================================
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        resp.setContentType("application/json;charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"message\":\"Vui lòng đăng nhập để thực hiện tác vụ.\"}");
            return;
        }
        NguoiDung currentUser = (NguoiDung) session.getAttribute("currentUser");

        try {
            // Lấy action từ Part
            String action = readPartToString(req.getPart("action"));
            
            if ("upload".equalsIgnoreCase(action)) { // Xử lý Tải lên mới
                handleNewContentUpload(req, resp, currentUser);
            } else if ("update".equalsIgnoreCase(action)) {
                handleContentUpdate(req, resp, currentUser); 
            } else if ("review".equalsIgnoreCase(action)) {
                handleContentReview(req, resp, currentUser); 
            } else {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"message\":\"Hành động POST không hợp lệ hoặc thiếu 'action' parameter.\"}");
            }

        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\":\"Lỗi Server khi xử lý yêu cầu: " + escapeJson(e.getMessage()) + "\"}");
        }
    }
    
    // ====================================================================
    // 3. doDelete: Xóa tài liệu (CÓ BẢO MẬT CHỐNG PATH TRAVERSAL)
    // ====================================================================
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        resp.setContentType("application/json;charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("{\"message\":\"Vui lòng đăng nhập để thực hiện tác vụ.\"}");
            return;
        }
        
        NguoiDung currentUser = (NguoiDung) session.getAttribute("currentUser");
        int nguoiDungId = currentUser.getId();

        String contentIdStr = req.getParameter("id");
        if (contentIdStr == null || contentIdStr.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"message\":\"Thiếu ID tài liệu để xóa.\"}");
            return;
        }
        
        int contentId = -1;
        try {
            contentId = Integer.parseInt(contentIdStr);
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"message\":\"ID tài liệu không hợp lệ.\"}");
            return;
        }

        try {
            conn = DBConnection.getDBConnection();
            conn.setAutoCommit(false);

            // --- 1. Lấy đường dẫn file cũ để xóa trên ổ đĩa ---
            String filePath = null;
            // Kiểm tra quyền: Chỉ cho phép chủ sở hữu xóa
            String sqlSelectFile = "SELECT duongdanfile FROM TaiLieu WHERE id = ? AND nguoidungid = ?";
            try (PreparedStatement stmtSelect = conn.prepareStatement(sqlSelectFile)) {
                stmtSelect.setInt(1, contentId);
                stmtSelect.setInt(2, nguoiDungId);
                try (ResultSet rs = stmtSelect.executeQuery()) {
                    if (rs.next()) {
                        filePath = rs.getString("duongdanfile");
                    } else {
                        resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
                        out.print("{\"message\":\"Không tìm thấy tài liệu hoặc bạn không có quyền xóa.\"}");
                        return;
                    }
                }
            }

            // --- 2. Xóa bản ghi trong Database ---
            String sqlDelete = "DELETE FROM TaiLieu WHERE id = ?";
            try (PreparedStatement stmtDelete = conn.prepareStatement(sqlDelete)) {
                stmtDelete.setInt(1, contentId);
                int rowsAffected = stmtDelete.executeUpdate();

                if (rowsAffected > 0) {
                    conn.commit();

                    // --- 3. Xóa file vật lý trên ổ đĩa (CÓ BẢO MẬT) ---
                    if (filePath != null && !filePath.isEmpty()) {
                        String uploadPath = getUploadPath(req);
                        // Chỉ lấy tên file từ đường dẫn lưu trong DB (ví dụ: uploads/abc.pdf -> abc.pdf)
                        String fileNameOnly = filePath.substring(UPLOAD_DIR.length() + 1); 
                        
                        String fullFilePath = uploadPath + File.separator + fileNameOnly;
                        
                        // 🔥 BẢO MẬT: Dùng getCanonicalFile() và kiểm tra thư mục gốc để ngăn Path Traversal
                        File uploadDir = new File(uploadPath).getCanonicalFile();
                        File fileToDelete = new File(fullFilePath).getCanonicalFile();
                        
                        // Kiểm tra file cần xóa có nằm trong thư mục gốc uploadDir không
                        if (fileToDelete.exists() && fileToDelete.getParentFile().equals(uploadDir)) {
                            if (!fileToDelete.delete()) {
                                System.err.println("Cảnh báo: Không thể xóa file an toàn: " + fileToDelete.getAbsolutePath());
                            }
                        } else if (fileToDelete.exists()) {
                            System.err.println("CẢNH BÁO BẢO MẬT: Phát hiện file nằm ngoài thư mục uploads bị bỏ qua: " + fileToDelete.getAbsolutePath());
                        }
                    }

                    resp.setStatus(HttpServletResponse.SC_OK);
                    out.print("{\"message\":\"Xóa tài liệu thành công!\"}");
                } else {
                    conn.rollback();
                    resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print("{\"message\":\"Xóa thất bại. Không tìm thấy tài liệu.\"}");
                }
            }

        } catch (SQLException e) {
            if (conn != null) try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\":\"Lỗi Database khi xóa tài liệu: " + escapeJson(e.getMessage()) + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"message\":\"Lỗi Server chung: " + escapeJson(e.getMessage()) + "\"}");
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }
    }

    /**
     * Xử lý Tải lên tài liệu mới (Initial Upload).
     */
    private void handleNewContentUpload(HttpServletRequest req, HttpServletResponse resp, NguoiDung currentUser) throws IOException, ServletException {
        PrintWriter out = resp.getWriter();
        Connection conn = null;

        try {
            conn = DBConnection.getDBConnection();
            conn.setAutoCommit(false);
            
            // 1. Lấy tham số từ form
            String tieuDe = readPartToString(req.getPart("tieuDe")); 
            String moTa = readPartToString(req.getPart("moTa")); 
            String phanLoai = readPartToString(req.getPart("phanLoai")); 
            String capDo = readPartToString(req.getPart("capDo")); // Lấy cấp độ mới
            Part filePart = req.getPart("fileUpload");

         // 🔥 CẬP NHẬT: Kiểm tra chuỗi rỗng và chuỗi chỉ chứa khoảng trắng bằng .trim().isEmpty()
            if (tieuDe == null || tieuDe.trim().isEmpty() || 
                moTa == null || moTa.trim().isEmpty() || 
                phanLoai == null || phanLoai.trim().isEmpty() ||
                filePart == null || filePart.getSize() == 0) {
                
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.write("{\"message\":\"Lỗi: Các trường Tiêu đề, Mô tả, Phân loại và File không được để trống!\"}");
                return;
            
            }

            // 2. Xử lý File và lưu vật lý
            String fileName = filePart.getSubmittedFileName();
            String fileExtension = "";
            int i = fileName.lastIndexOf('.');
            if (i > 0) {
                fileExtension = fileName.substring(i + 1).toLowerCase();
            }
            
            // Tạo tên file duy nhất
            String saveFileName = UUID.randomUUID().toString() + (i > 0 ? "." + fileExtension : "");
            String uploadPath = getUploadPath(req);
            String fullFilePath = uploadPath + File.separator + saveFileName;
            
            // Lưu file vật lý
            filePart.write(fullFilePath);
            
            // Chuẩn bị đường dẫn cho DB
            String dbFilePath = UPLOAD_DIR + "/" + saveFileName;
            
            // 3. Chèn bản ghi vào Database
            String insertSQL = "INSERT INTO TaiLieu (tieude, mota_ngan, loai_noi_dung, trangThai, tenFile, ngaytailen, nguoidungid, duongdanfile, tenfilegoc, dinhdang, cap_do) " // Thêm cap_do
                             + "VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?)";
            
            try(PreparedStatement stmt = conn.prepareStatement(insertSQL)) {
                stmt.setString(1, tieuDe);
                stmt.setString(2, moTa);
                stmt.setString(3, phanLoai);
                // Trạng thái mặc định khi tải lên là "Chờ duyệt"
                stmt.setString(4, "Chờ duyệt"); 
                stmt.setString(5, tieuDe);
                stmt.setInt(6, currentUser.getId());
                stmt.setString(7, dbFilePath);
                stmt.setString(8, fileName);
                stmt.setString(9, fileExtension);
                stmt.setString(10, capDo); // Thêm cấp độ

                int rowsAffected = stmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    conn.commit();
                    resp.setStatus(HttpServletResponse.SC_CREATED); // 201 Created
                    out.write("{\"message\":\"Tải tài liệu mới thành công. Tài liệu đang ở trạng thái Chờ duyệt!\"}");
                } else {
                    conn.rollback();
                    resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    out.write("{\"message\":\"Lỗi Database khi chèn bản ghi mới.\"}");
                    // Xóa file đã lưu nếu không chèn được vào DB
                    new File(fullFilePath).delete();
                }
            }

        } catch (Exception e) {
            if (conn != null) try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"message\":\"Lỗi Server khi tải lên: " + escapeJson(e.getMessage()) + "\"}");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }


    /**
     * Xử lý Phê duyệt/Từ chối tài liệu.
     */
    private void handleContentReview(HttpServletRequest req, HttpServletResponse resp, NguoiDung currentUser) throws IOException, ServletException {
        PrintWriter out = resp.getWriter();
        Connection conn = null;
        
        // Ghi chú: Logic kiểm tra quyền Admin đã được bình luận (comment out) theo yêu cầu trước đó.
        
        try {
            // Đọc từ Part vì đây là POST request có action=review trong form-data
            String contentIdStr = readPartToString(req.getPart("id"));
            String newStatus = readPartToString(req.getPart("trangThai"));
            
            if (contentIdStr == null || newStatus == null) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.write("{\"message\":\"Thiếu ID tài liệu hoặc trạng thái mới.\"}");
                return;
            }

            conn = DBConnection.getDBConnection();
            String updateSQL = "UPDATE TaiLieu SET trangThai = ? WHERE id = ?";
            try(PreparedStatement stmt = conn.prepareStatement(updateSQL)) {
                stmt.setString(1, newStatus);
                // Đảm bảo contentIdStr là số
                try {
                    stmt.setInt(2, Integer.parseInt(contentIdStr));
                } catch (NumberFormatException e) {
                    resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    out.write("{\"message\":\"ID tài liệu không hợp lệ.\"}");
                    return;
                }
                
                int rowsAffected = stmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    resp.setStatus(HttpServletResponse.SC_OK);
                    out.write("{\"message\":\"Cập nhật trạng thái thành công!\"}");
                } else {
                    resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.write("{\"message\":\"Không tìm thấy tài liệu để cập nhật.\"}");
                }
            }
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"message\":\"Lỗi Server khi duyệt nội dung: " + escapeJson(e.getMessage()) + "\"}");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }

    /**
     * Xử lý Cập nhật metadata tài liệu. BẢO MẬT trường trangThai và giới hạn quyền sửa.
     */
    private void handleContentUpdate(HttpServletRequest req, HttpServletResponse resp, NguoiDung currentUser) throws IOException, ServletException {
        PrintWriter out = resp.getWriter();
        Connection conn = null;

        try {
            conn = DBConnection.getDBConnection();
            conn.setAutoCommit(false);
            
            boolean isAdmin = "Admin".equalsIgnoreCase(currentUser.getVaitro()) || "Quản trị viên".equalsIgnoreCase(currentUser.getVaitro());

            // 1. Lấy tham số
            String contentIdStr = readPartToString(req.getPart("id"));
            String tieuDe = readPartToString(req.getPart("tieude"));
            String moTa = readPartToString(req.getPart("mota"));
            String phanLoai = readPartToString(req.getPart("phanloai"));
            String capDo = readPartToString(req.getPart("capDo")); // Lấy cấp độ
            String newStatus = readPartToString(req.getPart("trangThai")); 
            Part filePart = req.getPart("fileUpload");

            if (contentIdStr == null || tieuDe == null || moTa == null || phanLoai == null) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.write("{\"message\":\"Thiếu các trường bắt buộc (ID, Tiêu đề, Mô tả, Phân loại).\"}");
                return;
            }
            
            int contentId = Integer.parseInt(contentIdStr);

            // --- 2. Lấy thông tin cũ và xử lý File mới ---
            String oldFilePath = null;
            String oldDinhDang = null;
            String oldTenFileGoc = null;
            
            String sqlSelectOld = "SELECT duongdanfile, dinhdang, tenfilegoc FROM TaiLieu WHERE id = ?";
            try (PreparedStatement stmtSelect = conn.prepareStatement(sqlSelectOld)) {
                stmtSelect.setInt(1, contentId);
                try (ResultSet rs = stmtSelect.executeQuery()) {
                    if (rs.next()) {
                        oldFilePath = rs.getString("duongdanfile");
                        oldDinhDang = rs.getString("dinhdang");
                        oldTenFileGoc = rs.getString("tenfilegoc");
                    } else {
                        resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                        out.print("{\"message\":\"Không tìm thấy tài liệu cần cập nhật.\"}");
                        return;
                    }
                }
            }
            
            String newDbFilePath = oldFilePath;
            String newTenFileGoc = oldTenFileGoc;
            String newDinhDang = oldDinhDang;
            boolean newFileUploaded = false;
            
            if (filePart != null && filePart.getSize() > 0) {
                newFileUploaded = true;
                
                String fileName = filePart.getSubmittedFileName();
                String fileExtension = "";
                int i = fileName.lastIndexOf('.');
                if (i > 0) {
                    fileExtension = fileName.substring(i + 1).toLowerCase();
                }
                
                String saveFileName = UUID.randomUUID().toString() + (i > 0 ? "." + fileExtension : "");
                String uploadPath = getUploadPath(req);
                String filePath = uploadPath + File.separator + saveFileName;
                
                filePart.write(filePath);
                
                newDbFilePath = UPLOAD_DIR + "/" + saveFileName;
                newTenFileGoc = fileName;
                newDinhDang = fileExtension;
                
                // Xóa file cũ (CÓ BẢO MẬT)
                if (oldFilePath != null && !oldFilePath.isEmpty()) {
                    String oldFileNameOnly = oldFilePath.substring(UPLOAD_DIR.length() + 1);
                    String oldFullFilePath = uploadPath + File.separator + oldFileNameOnly;
                    
                    // 🔥 BẢO MẬT: Dùng getCanonicalFile() và kiểm tra thư mục gốc để ngăn Path Traversal
                    File uploadDir = new File(uploadPath).getCanonicalFile();
                    File oldFile = new File(oldFullFilePath).getCanonicalFile();
                    
                    if (oldFile.exists() && oldFile.getParentFile().equals(uploadDir)) {
                        if (!oldFile.delete()) {
                            System.err.println("Cảnh báo: Không thể xóa file cũ an toàn: " + oldFile.getAbsolutePath());
                        }
                    } else if (oldFile.exists()) {
                        System.err.println("CẢNH BÁO BẢO MẬT: Phát hiện file cũ nằm ngoài thư mục uploads bị bỏ qua: " + oldFile.getAbsolutePath());
                    }
                }
            }


            // 3. Xây dựng SQL (Bảo mật SQL linh hoạt)
            StringBuilder updateSQL = new StringBuilder("UPDATE TaiLieu SET tieude = ?, mota_ngan = ?, loai_noi_dung = ?, tenFile = ?, cap_do = ?"); // Thêm cap_do
            
            // 🔥 CHỈ THÊM TRƯỜNG TRẠNG THÁI NẾU LÀ ADMIN
            if (isAdmin && newStatus != null) {
                updateSQL.append(", trangThai = ?");
            }
            
            // Thêm đường dẫn file nếu file được tải lên mới
            if (newFileUploaded) {
                updateSQL.append(", duongdanfile = ?, tenfilegoc = ?, dinhdang = ?");
            }
            
            // 4. Điều kiện WHERE (Admin sửa bất kỳ ID nào, User chỉ sửa ID của chính họ)
            updateSQL.append(" WHERE id = ?");
            if (!isAdmin) {
                 updateSQL.append(" AND nguoidungid = ?");
            }


            // 5. Set tham số cho PreparedStatement
            try(PreparedStatement stmt = conn.prepareStatement(updateSQL.toString())) {
                int paramIndex = 1;

                stmt.setString(paramIndex++, tieuDe);
                stmt.setString(paramIndex++, moTa);
                stmt.setString(paramIndex++, phanLoai); // loai_noi_dung = phanLoai
                stmt.setString(paramIndex++, tieuDe); // tenFile (tên hiển thị) = tieude
                stmt.setString(paramIndex++, capDo); // cap_do

                // Trường Status (Chỉ cho Admin)
                if (isAdmin && newStatus != null) {
                    stmt.setString(paramIndex++, newStatus);
                }

                // Tham số file
                if (newFileUploaded) {
                    stmt.setString(paramIndex++, newDbFilePath);
                    stmt.setString(paramIndex++, newTenFileGoc);
                    stmt.setString(paramIndex++, newDinhDang);
                }

                // Điều kiện WHERE
                stmt.setInt(paramIndex++, contentId);
                if (!isAdmin) {
                    stmt.setInt(paramIndex++, currentUser.getId()); // Chỉ sửa tài liệu của chính họ
                }

                // 6. Thực thi và phản hồi
                int rowsAffected = stmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    conn.commit();
                    resp.setStatus(HttpServletResponse.SC_OK);
                    out.write("{\"message\":\"Cập nhật tài liệu thành công!\"}");
                } else {
                    conn.rollback();
                    resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
                    out.write("{\"message\":\"Cập nhật thất bại. (ID không tồn tại hoặc bạn không có quyền sửa tài liệu này).\"}");
                }
            }

        } catch (Exception e) {
            if (conn != null) try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"message\":\"Lỗi Server khi sửa nội dung: " + escapeJson(e.getMessage()) + "\"}");
        } finally {
            if (conn != null) try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
        }
    }
    
    
 // Trong TaiLieuActionsServlet.java
 // ... (các imports và định nghĩa class)

 // ...

     protected void doPost1(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         // ... (Code hiện tại của doPost)
         
         // 1. Phân biệt hành động (thêm vào đầu hàm doPost)
         String action = req.getParameter("action");
         if ("approve".equals(action) || "reject".equals(action)) {
             handleApprovalAction(req, resp, action);
             return; // Dừng lại, không chạy logic sửa nội dung thông thường
         }
         
         // ... (Logic xử lý sửa/tạo nội dung hiện tại của bạn)
     }

     /**
      * Xử lý các hành động phê duyệt/từ chối tài liệu.
      * Chỉ admin mới có quyền thực hiện.
      */
     private void handleApprovalAction(HttpServletRequest req, HttpServletResponse resp, String action) throws IOException {
         resp.setContentType("application/json");
         resp.setCharacterEncoding("UTF-8");
         PrintWriter out = resp.getWriter();
         Connection conn = null;

         // Lấy thông tin người dùng hiện tại (giả định đã có)
         NguoiDung currentUser = (NguoiDung) req.getSession().getAttribute("user");
         boolean isAdmin = currentUser != null && "admin".equals(currentUser.getVaitro());
         
         if (!isAdmin) {
             resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
             out.write("{\"message\":\"Bạn không có quyền thực hiện hành động này.\"}");
             return;
         }

         try {
             // Lấy ID tài liệu cần phê duyệt/từ chối
             int contentId = Integer.parseInt(req.getParameter("contentId"));
             
             // Xác định trạng thái mới
             int newTrangThai; // Giả định: 1 = Đã Phê Duyệt, 0 = Chờ Phê Duyệt, -1 = Bị Từ Chối
             String statusMessage;
             if ("approve".equals(action)) {
                 newTrangThai = 1; 
                 statusMessage = "phê duyệt";
             } else { // "reject"
                 newTrangThai = -1;
                 statusMessage = "từ chối";
             }

             conn = DBConnection.getDBConnection();
             conn.setAutoCommit(false); // Bắt đầu giao dịch

             String sql = "UPDATE TaiLieu SET TrangThai = ?, AdminPheDuyetID = ?, NgayCapNhat = NOW() WHERE ID = ?";
             
             try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                 stmt.setInt(1, newTrangThai);
                 stmt.setInt(2, currentUser.getId()); // Ghi lại Admin đã phê duyệt/từ chối
                 stmt.setInt(3, contentId);

                 int rowsAffected = stmt.executeUpdate();
                 
                 if (rowsAffected > 0) {
                     conn.commit();
                     resp.setStatus(HttpServletResponse.SC_OK);
                     out.write("{\"message\":\"Tài liệu ID " + contentId + " đã được " + statusMessage + " thành công.\"}");
                 } else {
                     conn.rollback();
                     resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                     out.write("{\"message\":\"Lỗi: Không tìm thấy tài liệu ID " + contentId + ".\"}");
                 }
             }

         } catch (NumberFormatException e) {
             resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
             out.write("{\"message\":\"Lỗi: contentId không hợp lệ.\"}");
         } catch (Exception e) {
             if (conn != null) try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
             e.printStackTrace();
             resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
             out.write("{\"message\":\"Lỗi Server khi " + action + ": " + escapeJson(e.getMessage()) + "\"}");
         } finally {
             if (conn != null) try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
         }
     }

    
}