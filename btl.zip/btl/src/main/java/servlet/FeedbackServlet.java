package servlet;

import dao.DBConnection; // Giả định class này cung cấp kết nối DB
import model.NguoiDung; // Giả định class này đại diện cho người dùng
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/api/feedback")
public class FeedbackServlet extends HttpServlet {

    /**
     * Xử lý yêu cầu POST để thêm một phản hồi (feedback) mới vào cơ sở dữ liệu.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Cấu hình phản hồi
        resp.setContentType("application/json;charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;

        // 1. KIỂM TRA PHÂN QUYỀN (AUTHENTICATION)
        HttpSession session = req.getSession(false);
        NguoiDung currentUser = (session != null) ? (NguoiDung) session.getAttribute("currentUser") : null;

        if (currentUser == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // 401 Unauthorized
            out.print("{\"message\":\"Lỗi: Vui lòng đăng nhập để gửi phản hồi.\"}");
            return;
        }

        // 2. LẤY VÀ XỬ LÝ DỮ LIỆU ĐẦU VÀO
        String noiDung = req.getParameter("noi_dung");
        String xepHangStr = req.getParameter("xep_hang");
        int nguoiDungId = currentUser.getId();
        int xepHang;

        // Kiểm tra dữ liệu bắt buộc (Validation)
        if (noiDung == null || noiDung.trim().isEmpty() || xepHangStr == null || xepHangStr.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400 Bad Request
            out.print("{\"message\":\"Lỗi: Nội dung và Xếp hạng không được để trống.\"}");
            return;
        }

        // Xử lý và kiểm tra lỗi ép kiểu NumberFormatException
        try {
            xepHang = Integer.parseInt(xepHangStr);
            // Kiểm tra ràng buộc CHECK (1 <= xep_hang <= 5)
            if (xepHang < 1 || xepHang > 5) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400
                out.print("{\"message\":\"Lỗi: Xếp hạng phải là số nguyên từ 1 đến 5.\"}");
                return;
            }
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400
            out.print("{\"message\":\"Lỗi: Xếp hạng phải là một số nguyên hợp lệ.\"}");
            return;
        }

        // 3. THAO TÁC CƠ SỞ DỮ LIỆU
        try {
            // Lấy kết nối
            conn = DBConnection.getDBConnection();
            conn.setAutoCommit(false); // Bắt đầu Transaction

            // Câu lệnh SQL: Chỉ chèn 3 cột (ngay_tao được DB tự động thêm)
            String sql = "INSERT INTO Feedback (nguoidungid, noi_dung, xep_hang) VALUES (?, ?, ?)";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, nguoiDungId);
                stmt.setString(2, noiDung.trim());
                stmt.setInt(3, xepHang);

                stmt.executeUpdate(); // Thực thi lệnh INSERT
            }

            conn.commit(); // Lưu thay đổi vào DB
            resp.setStatus(HttpServletResponse.SC_OK); // 200 OK
            out.print("{\"message\":\"Phản hồi của bạn đã được gửi thành công!\"}");

        } catch (SQLException e) {
            // Lỗi DB (Ví dụ: Lỗi Khóa ngoại, Lỗi kết nối, Lỗi SQL Syntax)
            if (conn != null) try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500 Internal Server Error
            // Sửa thông báo lỗi để rõ ràng hơn về nguyên nhân tiềm năng
            out.print("{\"message\":\"Lỗi server nội bộ: Lỗi Cơ sở dữ liệu hoặc người dùng không hợp lệ.\"}");
        } catch (Exception e) {
            // Lỗi lập trình không xác định khác
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500
            out.print("{\"message\":\"Lỗi server không xác định: " + e.getMessage() + "\"}");
        } finally {
            // Đóng kết nối
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }
}