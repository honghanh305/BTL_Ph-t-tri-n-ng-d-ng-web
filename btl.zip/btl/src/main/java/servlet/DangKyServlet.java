package servlet;

import dao.DBConnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/dangky")
public class DangKyServlet extends HttpServlet {
    
    // --- Hàm trích giá trị đơn giản từ chuỗi JSON (JSON Parsing thủ công - GIỮ NGUYÊN) ---
    private String getValue(String json, String key) {
        try {
            // Cải thiện logic parsing để tìm giá trị trong chuỗi JSON đơn giản
            String searchKey = "\"" + key + "\":\"";
            int keyIndex = json.indexOf(searchKey);
            if (keyIndex == -1) return "";
            
            int startValue = keyIndex + searchKey.length();
            
            // Tìm dấu nháy kép thứ hai (kết thúc value)
            int secondQuote = json.indexOf("\"", startValue);
            if (secondQuote == -1) return "";

            // Trích xuất và loại bỏ khoảng trắng dư thừa
            return json.substring(startValue, secondQuote).trim();
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json;charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;
        
        // 1. ĐỌC TOÀN BỘ JSON BODY TỪ REQUEST
        StringBuilder jsonBody = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                jsonBody.append(line);
            }
        } catch (Exception e) {
             resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); 
             out.print("{\"message\":\"Lỗi đọc dữ liệu request.\"}");
             return;
        }
        
        String json = jsonBody.toString();
        
        // 2. PARSE DỮ LIỆU TỪ JSON
        String hoten = getValue(json, "hoten");
        String email = getValue(json, "email");
        String matkhau = getValue(json, "matkhau");

        if (email.isEmpty() || matkhau.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); 
            out.print("{\"message\":\"Dữ liệu đăng ký thiếu trường email hoặc mật khẩu.\"}");
            return;
        }

        try {
            conn = DBConnection.getDBConnection();
            
            // a. KIỂM TRA EMAIL ĐÃ TỒN TẠI
            PreparedStatement check = conn.prepareStatement(
                "SELECT id FROM NguoiDung WHERE email=?");
            check.setString(1, email);
            ResultSet rs = check.executeQuery();

            if (rs.next()) {
                resp.setStatus(HttpServletResponse.SC_CONFLICT); // 409 Conflict
                out.print("{\"message\":\"Email đã tồn tại trong hệ thống!\"}");
                return;
            }

            // b. THỰC HIỆN ĐĂNG KÝ
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO NguoiDung (hoten, email, matkhau, vaitro) VALUES (?,?,?,?)");
            stmt.setString(1, hoten);
            stmt.setString(2, email);
            stmt.setString(3, matkhau);
            stmt.setString(4, "Student"); 
            stmt.executeUpdate();

            // 4. Phản hồi thành công
            resp.setStatus(HttpServletResponse.SC_OK); // 200 OK
            out.print("{\"message\":\"Đăng ký thành công! Bạn có thể đăng nhập ngay.\" }");
            
        } catch (Exception e) {
            // 5. Phản hồi lỗi Server (Lỗi DB hoặc Driver)
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500
            out.print("{\"message\":\"Lỗi server nội bộ: Không thể kết nối DB hoặc lỗi truy vấn.\"}");
        } finally {
             if (conn != null) {
                try { conn.close(); } catch (SQLException e) { /* Bỏ qua lỗi đóng kết nối */ }
            }
        }
    }
}