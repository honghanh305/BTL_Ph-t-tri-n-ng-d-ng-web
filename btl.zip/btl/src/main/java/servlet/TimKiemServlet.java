package servlet;

import dao.DBConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/timkiem")
public class TimKiemServlet extends HttpServlet {

    /**
     * Hàm tiện ích để escape các ký tự đặc biệt trong JSON và xử lý null/rỗng.
     * ✅ FIX QUAN TRỌNG: Thêm escape cho ký tự xuống dòng (\n, \r) 
     * Đây là nguyên nhân chính làm hỏng cấu trúc JSON, dẫn đến dữ liệu bị lẫn lộn.
     */
    private String safeString(String s) {
        if (s == null) return "";
        // Escape backslash, double quotes, newline, và carriage return
        return s.replace("\\", "\\\\") 
                .replace("\"", "\\\"") 
                .replace("\n", "\\n") 
                .replace("\r", "\\r");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json;charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;
        
        // 1. Lấy từ khóa tìm kiếm (chỉ lấy q)
        String query = req.getParameter("q");

        if (query == null || query.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); 
            out.print("{\"message\":\"Vui lòng cung cấp từ khóa tìm kiếm (tham số 'q').\"}");
            return;
        }

        try {
            conn = DBConnection.getDBConnection();
            
            // 2. CHUẨN BỊ SQL
            String sql = "SELECT "
                    + "T.id, T.tieude, T.mota_ngan, T.duongdanfile, T.dinhdang, ND.hoten, T.tenfilegoc, T.nguoidungid, T.muctaphocid, "
                    + "T.loai_noi_dung AS phanloai, " 
                    + "MTH.CapDo AS capdo " 
                    + "FROM TaiLieu T "
                    + "LEFT JOIN NguoiDung ND ON T.nguoidungid = ND.id "
                    + "LEFT JOIN MucTapHoc MTH ON T.muctaphocid = MTH.id " 
                    
                    // ✅ MỞ RỘNG TÌM KIẾM: Tìm trên nhiều trường và chỉ lấy tài liệu đã duyệt
                    + "WHERE T.trangThai = 'Đã duyệt' AND ("
                    + "LOWER(TRIM(T.tieude)) LIKE LOWER(?) OR "
                    + "LOWER(T.mota_ngan) LIKE LOWER(?) OR "
                    + "LOWER(T.loai_noi_dung) LIKE LOWER(?) OR "
                    + "LOWER(ND.hoten) LIKE LOWER(?)) "
                    
                    + "ORDER BY T.ngaytailen DESC";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            // Chuẩn hóa từ khóa tìm kiếm (thêm % và loại bỏ khoảng trắng)
            String searchPattern = "%" + query.trim() + "%";
            
            // Thiết lập 4 tham số cho 4 điều kiện tìm kiếm
            stmt.setString(1, searchPattern); 
            stmt.setString(2, searchPattern); 
            stmt.setString(3, searchPattern); 
            stmt.setString(4, searchPattern); 
            
            ResultSet rs = stmt.executeQuery();

            // 3. Xây dựng JSON phản hồi
            StringBuilder jsonResponse = new StringBuilder();
            jsonResponse.append("{\"message\":\"Tìm kiếm thành công.\",\"query\":\"").append(safeString(query)).append("\",\"results\":[");
            
            boolean first = true;
            while (rs.next()) {
                if (!first) {
                    jsonResponse.append(",");
                }
                
                int id = rs.getInt("id");
                String tieude = rs.getString("tieude");
                String motaNgan = rs.getString("mota_ngan");
                String duongdanfile = rs.getString("duongdanfile"); 
                String dinhdang = rs.getString("dinhdang");
                String hotenNguoiDang = rs.getString("hoten");
                String phanloai = rs.getString("phanloai"); 
                String capDo = rs.getString("capdo"); 
                int muctapHocId = rs.getInt("muctaphocid"); 
                
                // Giữ lại logic xử lý null/rỗng cho các trường hiển thị
                String finalTieuDe = (tieude == null || tieude.trim().isEmpty()) ? "Tài liệu không tên" : tieude;
                String finalDinhDang = (dinhdang == null || dinhdang.trim().isEmpty()) ? "N/A" : dinhdang;
                String finalNguoiDang = (hotenNguoiDang == null || hotenNguoiDang.isEmpty()) ? "Ẩn danh" : hotenNguoiDang;
                
                jsonResponse.append("{\"id\":").append(id).append(",");
                jsonResponse.append("\"tieuDe\":\"").append(safeString(finalTieuDe)).append("\","); 
                jsonResponse.append("\"moTaNgan\":\"").append(safeString(motaNgan)).append("\",");
                jsonResponse.append("\"duongDanFile\":\"").append(safeString(duongdanfile)).append("\",");
                jsonResponse.append("\"dinhDang\":\"").append(safeString(finalDinhDang)).append("\","); 
                jsonResponse.append("\"phanLoai\":\"").append(safeString(phanloai)).append("\",");
                jsonResponse.append("\"capDo\":\"").append(safeString(capDo)).append("\",");
                jsonResponse.append("\"muctapHocId\":").append(muctapHocId).append(","); 
                
                // ✅ ĐỒNG BỘ KEY: Đảm bảo key là "nguoiDang" để khớp với JavaScript Frontend
                jsonResponse.append("\"nguoiDang\":\"").append(safeString(finalNguoiDang)).append("\"");
                jsonResponse.append("}");
                
                first = false;
            }

            jsonResponse.append("]}");
            
            resp.setStatus(HttpServletResponse.SC_OK); 
            out.print(jsonResponse.toString());

        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); 
            out.print("{\"message\":\"Lỗi server nội bộ: " + safeString(e.getMessage()) + "\"}");
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); } 
            }
        }
    }
}