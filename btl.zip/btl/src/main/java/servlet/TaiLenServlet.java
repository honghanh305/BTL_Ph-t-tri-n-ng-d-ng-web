// TaiLenServlet.java đã đúng theo yêu cầu của bạn
package servlet;

import dao.DBConnection;
import model.NguoiDung; 
import java.io.*;
import java.sql.*;
import java.util.UUID;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 100,     // 100MB
    maxRequestSize = 1024 * 1024 * 150   // 150MB
)
@WebServlet("/tailen")
public class TaiLenServlet extends HttpServlet {
    
    private static final String UPLOAD_DIR = "uploads"; 

    // --- Hàm tiện ích: Đọc nội dung của Part thành String ---
    private String readPartToString(Part part) throws IOException {
        if (part == null) return null;
        try (java.util.Scanner scanner = new java.util.Scanner(part.getInputStream(), java.nio.charset.StandardCharsets.UTF_8.name())) {
            return scanner.hasNext() ? scanner.useDelimiter("\\A").next() : null;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json;charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;
        
        // 1. KIỂM TRA ĐĂNG NHẬP
        HttpSession session = req.getSession(false);
        int nguoiDungId = -1;
        
        // GIẢ ĐỊNH LOGIC LẤY USER TỪ SESSION HOẶC TOKEN
        if (session != null) {
             NguoiDung currentUser = (NguoiDung) session.getAttribute("currentUser");
             if (currentUser != null) {
                 nguoiDungId = currentUser.getId();
             } else {
                 // Nếu không tìm thấy trong session, thử lấy từ request (cho Ajax)
                 String nguoiDungIdStr = readPartToString(req.getPart("nguoiDungId"));
                 if (nguoiDungIdStr != null && nguoiDungIdStr.matches("\\d+")) {
                     nguoiDungId = Integer.parseInt(nguoiDungIdStr);
                 }
             }
        }
        
        if (nguoiDungId == -1) {
             resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // 401
             out.write("{\"message\":\"Lỗi xác thực: Vui lòng đăng nhập trước khi tải tài liệu.\"}");
             return;
        }
        
        // 2. LẤY DỮ LIỆU TỪ FORM 
        Part filePart = null;
        String moTaNgan = null;
        String tenNoiDung = null;
        String mucTapHocIdStr = null;
        String loaiNoiDungStr = null; // <-- Bổ sung trường mới
        String moTaChiTiet = null; // Trường contentDescription (nếu có)

        try {
            // Lấy file (Tên trường: fileUpload)
            filePart = req.getPart("fileUpload");

            // Lấy các trường text bằng hàm tiện ích
            moTaNgan = readPartToString(req.getPart("fileDescription")); // Dành cho form trang chủ
            tenNoiDung = readPartToString(req.getPart("contentName"));    // Dành cho form Tạo nội dung
            mucTapHocIdStr = readPartToString(req.getPart("mucTapHocId")); 
            loaiNoiDungStr = readPartToString(req.getPart("loaiNoiDung")); // <-- Lấy trường mới
            moTaChiTiet = readPartToString(req.getPart("contentDescription")); // Dành cho form Tạo nội dung
            
            // Validation cơ bản
            if (filePart == null || filePart.getSize() == 0) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400
                out.write("{\"message\":\"Lỗi: Vui lòng chọn một tệp để tải lên.\"}");
                return;
            }
            if ((tenNoiDung == null || tenNoiDung.trim().isEmpty()) && (moTaNgan == null || moTaNgan.trim().isEmpty())) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); // 400
                out.write("{\"message\":\"Lỗi: Vui lòng nhập Tiêu đề hoặc Mô tả ngắn cho tài liệu.\"}");
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"message\":\"Lỗi server khi phân tích dữ liệu form.\"}");
            return;
        }
        
        // Xử lý tên file và định dạng
        String fileName = filePart.getSubmittedFileName();
        String fileExtension = "";
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex > 0) {
            fileExtension = fileName.substring(dotIndex + 1).toLowerCase();
        }

        // Định hình các giá trị cuối cùng cho DB
        String tieuDeFinal = (tenNoiDung != null && !tenNoiDung.isEmpty()) ? tenNoiDung : fileName;
        // Ưu tiên Mô tả chi tiết (contentDescription) cho mô tả ngắn nếu có
        String moTaNganFinal = (moTaChiTiet != null && !moTaChiTiet.isEmpty()) ? moTaChiTiet : 
                               (moTaNgan != null && !moTaNgan.isEmpty()) ? moTaNgan : 
                               "Tài liệu không có mô tả ngắn.";

        // Lấy muctaphocid (Giả định ID 101 là giá trị mặc định nếu rỗng) 
        int mucTapHocId = 101; 
        if (mucTapHocIdStr != null && mucTapHocIdStr.matches("\\d+")) {
            mucTapHocId = Integer.parseInt(mucTapHocIdStr);
        }
        
        // Lấy loai_noi_dung, mặc định là "Document"
        String loaiNoiDung = (loaiNoiDungStr != null && !loaiNoiDungStr.isEmpty()) ? loaiNoiDungStr : "Document";

        
        // 3. LƯU TRỮ FILE VÀO HỆ THỐNG
        String appPath = req.getServletContext().getRealPath("");
        String savePath = appPath + File.separator + UPLOAD_DIR;

        // Tạo thư mục nếu chưa tồn tại
        File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists()) fileSaveDir.mkdirs();

        // Tạo tên file ngẫu nhiên để tránh trùng lặp
        String uniqueFileName = UUID.randomUUID().toString() + "_" + fileName;
        String dbFilePath = UPLOAD_DIR + "/" + uniqueFileName;
        
        // Ghi file ra ổ đĩa
        filePart.write(savePath + File.separator + uniqueFileName);
        
        // 4. LƯU THÔNG TIN VÀO CƠ SỞ DỮ LIỆU
        try {
            conn = DBConnection.getDBConnection();
            conn.setAutoCommit(false);

            // Columns: muctaphocid, tieude, mota_ngan, duongdanfile, tenfilegoc, dinhdang, nguoidungid, loai_noi_dung, tenFile, ngaytailen
            String insertTaiLieuSQL = "INSERT INTO TaiLieu (muctaphocid, tieude, mota_ngan, duongdanfile, tenfilegoc, dinhdang, nguoidungid, loai_noi_dung, tenFile, ngaytailen) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            
            PreparedStatement stmt2 = conn.prepareStatement(insertTaiLieuSQL);
            
            // THIẾT LẬP 9 THAM SỐ 
            stmt2.setInt(1, mucTapHocId);             // 1. muctaphocid (Int)
            stmt2.setString(2, tieuDeFinal);          // 2. tieude (String)
            stmt2.setString(3, moTaNganFinal);        // 3. mota_ngan (String)
            stmt2.setString(4, dbFilePath);           // 4. duongdanfile (String)
            stmt2.setString(5, fileName);             // 5. tenfilegoc (String)
            stmt2.setString(6, fileExtension);        // 6. dinhdang (String)
            stmt2.setInt(7, nguoiDungId);             // 7. nguoidungid (Int)
            stmt2.setString(8, loaiNoiDung);          // 8. loai_noi_dung (String)
            stmt2.setString(9, tieuDeFinal);          // 9. tenFile (String)
            
            stmt2.executeUpdate();

            conn.commit(); 
            
            resp.setStatus(HttpServletResponse.SC_OK);
            out.write("{\"message\":\"🎉 Đăng tải tài liệu thành công! Bạn có thể xem nó trong mục Khám phá.\"}");

        } catch (SQLException e) {
            if (conn != null) try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"message\":\"Lỗi Database khi tải lên: " + e.getMessage() + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"message\":\"Lỗi server khi xử lý file: " + e.getMessage() + "\"}");
        } finally {
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}