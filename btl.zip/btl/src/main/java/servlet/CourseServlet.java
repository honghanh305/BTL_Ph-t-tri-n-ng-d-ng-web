package servlet;
import dao.DBConnection;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/api/courses")
public class CourseServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;

        StringBuilder jsonResponse = new StringBuilder();
        List<String> courseList = new ArrayList<>();

        try {
            conn = DBConnection.getDBConnection();

            // ⚠️ ĐÃ SỬA: SỬ DỤNG JOIN VÀ TÊN CỘT CHÍNH XÁC TỪ SCHEMA
            String sql = "SELECT M.tenmuctaphoc, M.CapDo, N.hoten AS GiangVien, M.IconClass, M.BgClass " +
                         "FROM MucTapHoc M " +
                         "JOIN NguoiDung N ON M.nguoidungid = N.id " + // Lấy tên giảng viên
                         "ORDER BY M.id DESC LIMIT 8"; 

            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                
                while (rs.next()) {
                    // ⚠️ ĐÃ SỬA: Lấy dữ liệu từ tên cột mới/đã sửa
                    String title = rs.getString("tenmuctaphoc");
                    String level = rs.getString("CapDo");
                    String teacher = rs.getString("GiangVien"); // Sử dụng tên alias từ JOIN
                    String icon = rs.getString("IconClass"); 
                    String bg = rs.getString("BgClass");   
                    
                    // Xây dựng JSON object cho mỗi khóa học (Escape characters)
                    String courseJson = String.format(
                        "{\"title\":\"%s\",\"level\":\"%s\",\"teacher\":\"%s\",\"icon\":\"%s\",\"bg\":\"%s\"}",
                        title.replace("\"", "\\\""), 
                        level.replace("\"", "\\\""), 
                        teacher.replace("\"", "\\\""),
                        icon.replace("\"", "\\\""), 
                        bg.replace("\"", "\\\"")
                    );
                    courseList.add(courseJson);
                }
            }

            // Gộp các JSON object thành một JSON array
            jsonResponse.append("{\"courses\":[");
            jsonResponse.append(String.join(",", courseList));
            jsonResponse.append("],\"message\":\"Tải danh sách khóa học thành công!\"}");

            resp.setStatus(HttpServletResponse.SC_OK); 
            out.print(jsonResponse.toString());

        } catch (Exception e) {
            // ⚠️ ĐÃ SỬA: Log lỗi rõ ràng hơn
            System.err.println("❌ LỖI TRUY VẤN KHÓA HỌC: ");
            e.printStackTrace(); 
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); 
            out.print("{\"message\":\"Lỗi server nội bộ: Không thể tải danh sách khóa học. Chi tiết: " + e.getMessage() + "\"}");
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }
    }
}