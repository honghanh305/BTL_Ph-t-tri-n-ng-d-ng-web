package servlet;

import dao.DBConnection;
import model.NguoiDung; 
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/dangnhap")
public class DangNhapServlet extends HttpServlet {
    
    // --- Hàm trích giá trị đơn giản từ chuỗi JSON (JSON Parsing thủ công - GIỮ NGUYÊN) ---
    private String getValue(String json, String key) {
         try {
            // Cải thiện logic parsing để tìm giá trị trong chuỗi JSON đơn giản
            String searchKey = "\"" + key + "\":\"";
            int keyIndex = json.indexOf(searchKey);
            if (keyIndex == -1) return "";
            
            int startValue = keyIndex + searchKey.length();
            
            // Tìm dấu nháy kép thứ hai (kết thúc value)
            int secondQuote = json.indexOf("\"", startValue);
            if (secondQuote == -1) return "";

            // Trích xuất và loại bỏ khoảng trắng dư thừa
            return json.substring(startValue, secondQuote).trim();
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json;charset=UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = resp.getWriter();
        Connection conn = null;
        
        // 1. ĐỌC TOÀN BỘ JSON BODY TỪ REQUEST
        StringBuilder jsonBody = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                jsonBody.append(line);
            }
        } catch (Exception e) {
             resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); 
             out.print("{\"message\":\"Lỗi đọc dữ liệu request.\"}");
             return;
        }
        
        String json = jsonBody.toString();
        
        // 2. PARSE DỮ LIỆU TỪ JSON
        String email = getValue(json, "email");
        String matkhau = getValue(json, "matkhau");

        if (email.isEmpty() || matkhau.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST); 
            out.print("{\"message\":\"Dữ liệu đăng nhập thiếu trường email hoặc mật khẩu.\"}");
            return;
        }

        try {
            conn = DBConnection.getDBConnection();
            
            // a. TÌM KIẾM THEO EMAIL
            PreparedStatement emailStmt = conn.prepareStatement(
                "SELECT id, hoten, matkhau, vaitro FROM NguoiDung WHERE email=?");
            emailStmt.setString(1, email);
            ResultSet emailRs = emailStmt.executeQuery();

            if (!emailRs.next()) {
                // Không tìm thấy email
                resp.setStatus(HttpServletResponse.SC_NOT_FOUND); // 404 Not Found
                out.print("{\"message\":\"Email không tồn tại trong hệ thống!\"}");
                return;
            }
            
            // Lấy dữ liệu người dùng
            int id = emailRs.getInt("id");
            String hoten = emailRs.getString("hoten");
            String storedMatkhau = emailRs.getString("matkhau"); 
            String vaitro = emailRs.getString("vaitro");

            // b. SO SÁNH MẬT KHẨU
            if (matkhau.equals(storedMatkhau)) {
                // THÀNH CÔNG: TẠO OBJECT VÀ LƯU SESSION
                NguoiDung currentUser = new NguoiDung(id, hoten, email, storedMatkhau, vaitro);
                
                HttpSession session = req.getSession();
                session.setAttribute("currentUser", currentUser); 

                // Gửi phản hồi về client
                resp.setStatus(HttpServletResponse.SC_OK); // 200 OK
                out.print("{\"id\":" + id + ",\"hoten\":\"" + hoten + "\",\"email\":\"" + email + "\",\"vaitro\":\"" + vaitro + "\",\"message\":\"Đăng nhập thành công!\"}");

            } else {
                // Sai mật khẩu
                resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // 401 Unauthorized
                out.print("{\"message\":\"Sai mật khẩu!\"}");
            }

        } catch (Exception e) {
            // Lỗi DB hoặc lỗi khác
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500
            out.print("{\"message\":\"Lỗi server nội bộ: Không thể kết nối DB hoặc lỗi truy vấn.\"}");
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException e) { /* Bỏ qua lỗi đóng kết nối */ }
            }
        }
    }
}