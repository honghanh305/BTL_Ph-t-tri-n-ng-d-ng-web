package model;

import java.io.Serializable;

// Cần implements Serializable để lưu trữ đối tượng trong HttpSession
public class NguoiDung implements Serializable {
    private int id;
    private String hoten;
    private String email;
    private String matkhau;
    private String vaitro;

    public NguoiDung() {}

    // Constructor cho Đăng ký (không có ID)
    public NguoiDung(String hoten, String email, String matkhau, String vaitro) {
        this.hoten = hoten;
        this.email = email;
        this.matkhau = matkhau;
        this.vaitro = vaitro;
    }
    
    // Constructor cho Đăng nhập (có ID)
    public NguoiDung(int id, String hoten, String email, String matkhau, String vaitro) {
        this.id = id;
        this.hoten = hoten;
        this.email = email;
        this.matkhau = matkhau;
        this.vaitro = vaitro;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getHoten() { return hoten; }
    public void setHoten(String hoten) { this.hoten = hoten; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getMatkhau() { return matkhau; }
    public void setMatkhau(String matkhau) { this.matkhau = matkhau; }

    public String getVaitro() { return vaitro; }
    public void setVaitro(String vaitro) { this.vaitro = vaitro; }
}